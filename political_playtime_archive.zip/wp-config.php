<?php


// ** MySQL settings ** //
/** The name of the database for WordPress */
define('DB_NAME', 'political_playtime115720160318');

/** MySQL database username */
define('DB_USER', '561_media');

/** MySQL database password */
define('DB_PASSWORD', '561_media');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

define('AUTH_KEY',         't)L:kq9!s+t51G^G1t}+B58%%>^+]je~n0Mj@x7y3Th O7kt>!VR$qp,o|+$|jC.');
define('SECURE_AUTH_KEY',  'q-_9v=<YHWjp2-+4RI|Cz|P-.x0E)*gA885`EU#,9W2ht.&=?TwZ/xu!MTATo)FC');
define('LOGGED_IN_KEY',    'f+x?)umF3=CQ3d%v;Vv0$,doT0q-^^n&Xqe!hy|+*U7,dPoM.cX`MmjO|1FzcD3+');
define('NONCE_KEY',        '<*/FZ!%)@Q)-$aavV(o`h$z080&VB,wV</$^&rSlE}XN7NWak2t$bNypu[<uzKuJ');
define('AUTH_SALT',        'ZJ&|vp8xeL:H~#Z!e]`+-|<Cjt#0wjMjwBA:,Qy%zpyh{z_Krh _e#D)SD68n^3z');
define('SECURE_AUTH_SALT', '+g2x[*..r@KZy&Jcg0%{=4jfVu$|O>o=w7Y-Gl1Oo^n|++6{-S57<+f5D`H=_Cz!');
define('LOGGED_IN_SALT',   'bW-Q^&4@0=gk;tLC]bN^pkH!VG98U~>y4H($C-(Gs##eI,HED-; >SV#aG+P}0} ');
define('NONCE_SALT',       'W1o`xlv<Tj5`-EQP~mBA#0mF*Di!f6=9X*]${`CT23A+P!/[~KCY_kQ{rONa>k#^');


$table_prefix = 'wp_';





/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
define('WP_DEBUG',true);
define('FS_METHOD','direct');
